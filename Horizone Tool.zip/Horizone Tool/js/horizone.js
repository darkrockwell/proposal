/*------------------------------------

Project Name: Horizone Tool
Author: SME Innovation Team
Date: April 2020
Version: 1.0.0
Company: Majorel PH

---------------------------------------*/


var handleSrtGUI = function(){

$('body').prepend('<div class="horizone-element bootstrap inspinia" style="display: block"></div>');

$.get(chrome.extension.getURL('horizone.html'), function(data) {
	$(data).appendTo('.horizone-element');
});


// Current Time

setInterval(function(){
	$('.srt-time').text(formatAMPM(new Date));
}, 1000);

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ampm;
  return strTime;
}



},
handleInterface = function(){

var gui = false;

$(document).on('keydown', function(e){

	if(e.which == 45){
		
		if(!gui){
			$('.app-block').fadeIn();
			gui = true;
		}
		else {
			$('.app-block').fadeOut();
			gui = false;
		}

		//console.log(gui);
		
	}


});


$(document).on('click', '.menu-open-button', function(){
   	$('.app-block').fadeIn();
    gui = true;
});

/* Menu
--------------------------------------------*/

$(document).on('click', '.menu-item', function(){

	$('.highlighter-data').html('');

	$('.shortcut-menu a').removeClass('active');
	$(this).toggleClass('active');

	if ($(this).hasClass('m-idle-timer')){

		$('.highlighter-block, .highlighter-kb-block, .pos-tags, .t2s-note, .att-note, .note-announce, .text2speech-content, .highlight-f, .text2speech-f, .tagging-tree-content').fadeOut(100, function(){
			$('.idle-timer-content, .idle-note').fadeIn(1000);
		});
		
	}



});

},
handleFullScreenMode = function(){

/* Get the element you want displayed in fullscreen mode (a video in this example): */
var elem = document.documentElement;
var fullScreenStatus = false;

$(document).on('click', '.m-fullscreen', function(){
	

	if(!fullScreenStatus){
		$('.m-fullscreen i').removeClass('ion-md-expand').addClass('ion-md-contract');
		openFullscreen(elem);
		fullScreenStatus = true;
	}
	else {
		$('.m-fullscreen i').removeClass('ion-md-contract').addClass('ion-md-expand');
		closeFullscreen();
		fullScreenStatus = false;
	}
});

	/* When the openFullscreen() function is executed, open the video in fullscreen.
	Note that we must include prefixes for different browsers, as they don't support the requestFullscreen method yet */
	function openFullscreen() {
	  if (elem.requestFullscreen) {
	    elem.requestFullscreen();
	  } else if (elem.mozRequestFullScreen) { /* Firefox */
	    elem.mozRequestFullScreen();
	  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
	    elem.webkitRequestFullscreen();
	  } else if (elem.msRequestFullscreen) { /* IE/Edge */
	    elem.msRequestFullscreen();
	  }
	}

	function closeFullscreen() {
	  if (document.exitFullscreen) {
	    document.exitFullscreen();
	  } else if (document.mozCancelFullScreen) { /* Firefox */
	    document.mozCancelFullScreen();
	  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
	    document.webkitExitFullscreen();
	  } else if (document.msExitFullscreen) { /* IE/Edge */
	    document.msExitFullscreen();
	  }
	}

},
handleAppSettings = function(){

console.log('app settings ok!');

},
handleIdleTimer = function(){

	var audio_url = chrome.runtime.getURL('audio/bells.mp3');
  	var audio = new Audio(audio_url);

  	var timerStartIn = 6;

	var timer = -1;
	var idle = null;
	var storage = false;
	var isTimerStarted = false;

	var timeOut = null;


	$(document).on('mousemove', function(){

		
		clearTimeout(timeOut);

		timeOut = setTimeout(function(){
			chrome.storage.local.set({storageTimer: Date.now()}, function() {
				//console.log('Value is set to ' + Date.now());
			});
		}, 10);
        
  	});

	chrome.storage.onChanged.addListener(function(changes, namespace) {
	    IT();
	    //console.log('changes');
	});

	function IT(){
		
		clearInterval(idle);
		timer = -1;

		audio.pause(); // Stop playing
        audio.currentTime = 0; // Reset time
        
        timerStartIn = 6;
        $('.timer').html('Reviewer is active');
        $('.timer-content i').removeClass('animated shake infinite');
        $('.it-status').html('<span> <strong>Reviewer Status: </strong> <span class="active m-r-10">Active</span></span>');
	      
        idle = setInterval(function(){

            timer++;
           	//console.log(timer);

           	 timerStartIn--;
        	$('.timer').html('Reviewer is active. <br> Idle starts in ' + timerStartIn + ' second/s');

            if(timer >= 5){
             	//Idle
             	//console.log('Idle madafaka');

             	$('.timer').html('You are idle for about <br> ' + secondsToHms(timer - 5) +'.');
                //console.log(timer);
                audio.play();
                $('.timer-content i').addClass('animated shake infinite');
                $('.it-status').html('<span> <strong>Reviewer Status: </strong> <span class="idle m-r-10">Idle</span></span>');
      
            }
            
        }, 1000);
	}


},
Main = function() {
    'use strict';

    return {
        init: function() {

			var d = Date.now();
			var appToken = 1591190664000;
			
			if(d <= appToken){

				handleSrtGUI(),
				handleInterface(),
				handleFullScreenMode(),
				handleAppSettings(),
				handleIdleTimer()
					
			} else {
				console.log('Something went wrong. Contact Saitama!');
			}
	
        }
    }
}();
Main.init();

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

function secondsToHms(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);

    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay + sDisplay; 
}
