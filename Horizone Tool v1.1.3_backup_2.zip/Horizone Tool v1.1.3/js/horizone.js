/*------------------------------------

Project Name: Horizone Tool
Author: SME Innovation Team
Date: April 2020
Version: 1.1.3
Company: Majorel PH

---------------------------------------*/


var handleSrtGUI = function(){

$('body').prepend('<div class="horizone-element bootstrap" style="display: block"></div>');

$.get(chrome.extension.getURL('horizone.html'), function(data) {
	$(data).appendTo('.horizone-element');
});

var image = '<img src="'+chrome.runtime.getURL("images/login-1.png")+'" class="img-responsive" style="height: 140px; margin-top: 10px">';

setTimeout(function(){
 $('.login-img').append(image);
},300);


},
handleInterface = function(){

var gui = false;

$(document).on('keydown', function(e){

	if(e.which == 45){
		
		if(!gui){
			
			if($('.app-block')[0]){
				$('.app-block').fadeIn();
			}

			if($('.app-login-block')[0]){
				$('.app-login-block').fadeIn();
			}

			gui = true;
		}
		else {
			if($('.app-block')[0]){
				$('.app-block').fadeOut();
			}

			if($('.app-login-block')[0]){
				$('.app-login-block').fadeOut();
			}
			gui = false;
		}

		//console.log(gui);
		
	}


});


$(document).on('click', '.menu-open-button', function(){
   	$('.app-block').fadeIn();
    gui = true;
});

/* Menu
--------------------------------------------*/

$(document).on('click', '.menu-item', function(){

	$('.highlighter-data').html('');

	$('.shortcut-menu a').removeClass('active');
	$(this).toggleClass('active');

	if ($(this).hasClass('m-idle-timer')){

		showIdleTimer();
		hideText2Speech();
		hideChronopeg();
		
	}
	if ($(this).hasClass('m-texttospeach')){

		showText2Speech();
		hideIdleTimer();
		hideChronopeg();

	}
	if ($(this).hasClass('m-chronopeg')){

		showChronopeg();
		hideIdleTimer();
		hideText2Speech();

	}

	function showIdleTimer(){
		$('.idle-timer-content, .idle-note').fadeIn(1000);
	}
	function hideIdleTimer(){
		$('.idle-timer-content, .idle-note').fadeOut(1000);
	}
	function showText2Speech(){
		$('.text2speech-content, .t2s-note').fadeIn(1000);
	}
	function hideText2Speech(){
		$('.text2speech-content, .t2s-note').fadeOut(1000);
	}
	function showChronopeg(){
		$('.chronopeg-content, .chpeg-note').fadeIn(1000);
	}
	function hideChronopeg(){
		$('.chronopeg-content, .chpeg-note').fadeOut(1000);
	}


});

},
handleFullScreenMode = function(){

/* Get the element you want displayed in fullscreen mode (a video in this example): */
var elem = document.documentElement;
var fullScreenStatus = false;

$(document).on('click', '.m-fullscreen', function(){
	

	if(!fullScreenStatus){
		$('.m-fullscreen i').removeClass('ion-md-expand').addClass('ion-md-contract');
		openFullscreen(elem);
		fullScreenStatus = true;
	}
	else {
		$('.m-fullscreen i').removeClass('ion-md-contract').addClass('ion-md-expand');
		closeFullscreen();
		fullScreenStatus = false;
	}
});

	/* When the openFullscreen() function is executed, open the video in fullscreen.
	Note that we must include prefixes for different browsers, as they don't support the requestFullscreen method yet */
	function openFullscreen() {
	  if (elem.requestFullscreen) {
	    elem.requestFullscreen();
	  } else if (elem.mozRequestFullScreen) { /* Firefox */
	    elem.mozRequestFullScreen();
	  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
	    elem.webkitRequestFullscreen();
	  } else if (elem.msRequestFullscreen) { /* IE/Edge */
	    elem.msRequestFullscreen();
	  }
	}

	function closeFullscreen() {
	  if (document.exitFullscreen) {
	    document.exitFullscreen();
	  } else if (document.mozCancelFullScreen) { /* Firefox */
	    document.mozCancelFullScreen();
	  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
	    document.webkitExitFullscreen();
	  } else if (document.msExitFullscreen) { /* IE/Edge */
	    document.msExitFullscreen();
	  }
	}

},
handleTextToSpeech = function(){

var rat, pit, vol, voice;
var pausere_status = false;

voice = 'Microsoft David Desktop - English (United States)';

rat = 1;
pit = 1.30;
vol = 1;


$(document).on('click', '.t-play', function(){

	speak('.t2p-text', voice, rat, pit, vol);

});

$(document).on('click', '.t-pause-resume', function(){
	
	if(!pausere_status){
		pause();
		pausere_status = true;
	} 
	else if(pausere_status){
		resume();
		pausere_status = false;
	}

});

$(document).on('click', '.t-stop', function(){
	
	 $().articulate('stop');

});

// Get the text from $('._775z._6zpm') class;

$(document).on('click', '.btn-main-component', function(){

	$('.t2p-text').remove();
	$('.text2speech-content').prepend('<div class="t2p-text"></div>');

	var txt_component = $('._775z._6zpm').first().text();
	$('.custom-t2p').val(txt_component);
	$('.t2p-text').html('<span class="t2p-main">'+txt_component+'</span>');

	console.log(txt_component);

});

$(document).on('click', '.btn-srt-translation', function(){

	$('.t2p-text').remove();
	$('.text2speech-content').prepend('<div class="t2p-text"></div>');
	
	var txt_translation = $('._775z._6zpm').last().text();
	$('.custom-t2p').val(txt_translation);
	$('.t2p-text').html('<span class="t2p-main">'+txt_translation+'</span>');


	console.log(txt_translation);

});


function speak(obj, voice, rat, pit, vol) {
  $(obj).articulate('setVoice','name',voice).articulate('rate', rat).articulate('pitch', pit).articulate('volume', vol).articulate('speak');
}

function pause() {
  $().articulate('pause');
}

function resume() {
  $().articulate('resume');
}

function stop() {
  $().articulate('stop');
}


},
handleChronopeg = function(){

	$(document).on('click', '.ch-save-time-consumed', function(){

		var action = "Save Chrono Peg";
		var selected_peg = $('.ch-select-peg').val();
		var time_consumed = $('.ch-time-consumed').val();
		alert(selected_peg + ' & ' + time_consumed);

		chrome.storage.local.get("h_t_revid", function(res) {

			console.log('Reviewer ID: ' + res.h_t_revid);

			//For development purpose only. Soon we will switch on more secured server.
			$.ajax({
		        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chronopeg_exec.php',
		        type: 'POST',
		        data: {action:action, reviewer_id:res.h_t_revid, selected_peg:selected_peg, time_consumed:time_consumed},
		        dataType: 'json',
		        success: function(data){
		        	
		        	console.log('Chronopeg Status: ' + data);
		        	console.log('Chronopeg Status: ' + data.exec_message);

		        	if(data.exec_message == 'Success!'){
		        		
		        	}

		        },
		        error: function(jxhr){
	               //console.log(jxhr.responseText);
	               console.log('Chronopeg Save Error');
	           }
		    });

		});

	});

	$(document).on('click', '.ch-get-data', function(){
		getChronoPegData();
	});

	function getChronoPegData(){

		var getChronoData = 'Get Chrono Peg';

		$.ajax({
		        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chronopeg_exec.php',
		        type: 'POST',
		        data: {getChronoData:getChronoData},
		        dataType: 'json',
		        success: function(data){
		        	
		        	console.log('Chronopeg Get Status: ' + data);

		        	var obj = data;
		        	var result = Object.keys(obj).map(function(key) {
					  return [key, obj[key]];
					});

					console.log(result[0]);

		        },
		        error: function(jxhr){
	               //console.log(jxhr.responseText);
	               console.log('Chronopeg Save Error');
	           }
		    });

	}

},
handleIdleTimer = function(){

	var audio_url = chrome.runtime.getURL('audio/bells.mp3');
  	var audio = new Audio(audio_url);

  	var timerStartIn;
	var timer;
	var idle = null;
	var timeOut = null;
	var MouseMoved = 0;

	var reviewer_id;
	var reviewer_status = '';
	var action = '';

	//Setting Local Storage Default Value if nothing is set.
	if(localStorage.getItem('isUserClickedUnavailable') == null){localStorage.setItem('isUserClickedUnavailable', 'No')}
	if(localStorage.getItem('revStatusStorage') == null){localStorage.setItem('revStatusStorage', 'Unavailable')}



	setTimeout(function(){

		if(localStorage.getItem('changePegStorage') == 'Pending'){

			console.log('Ajax Request!');

		    chrome.storage.local.get("h_t_revid", function(res) {

				reviewer_id = res.h_t_revid;
				console.log('Reviewer ID: ' + reviewer_id);

				action = 'Reviewer Change Status';
				var c_reviewer_status = localStorage.getItem('revStatusStorage');

				//For development purpose only. Soon we will switch on more secured server.
				$.ajax({
			        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
			        type: 'POST',
			        data: {action:action, reviewer_id:reviewer_id, reviewer_status:c_reviewer_status},
			        dataType: 'json',
			        success: function(data){
			        	
			        	console.log('Change Peg Post: ' + data.exec_message);

			        	if(data.exec_message == 'Success!'){
			        		localStorage.setItem('changePegStorage', 'Post Done!');
			        	}

			        },
			        error: function(jxhr){
		               //console.log(jxhr.responseText);
		               console.log('Send Pending Failed');
		           }
			    });

			});

		}

	}, 3000);

	setTimeout(function(){

		//Check peg


		if($('._699p ._699o').text()[0]){

			if($('._699p ._699o').text() == "In production"){

				reviewer_status = $('._699p ._699o').text();
				localStorage.setItem('revStatusStorage', reviewer_status);
				localStorage.setItem('isUserClickedUnavailable', 'No');
				localStorage.setItem('changePegStorage', 'Check Peg');

				console.log(localStorage.getItem('revStatusStorage'));
				console.log(localStorage.getItem('changePegStorage'));

			}

		}

		
		if(localStorage.getItem('changePegStorage') == 'Check Peg'){

			console.log('Ajax Request Check Peg!');

		    chrome.storage.local.get("h_t_revid", function(res) {

				reviewer_id = res.h_t_revid;
				console.log('Reviewer ID: ' + reviewer_id);

				action = 'Reviewer Change Status';
				var c_reviewer_status = localStorage.getItem('revStatusStorage');

				//For development purpose only. Soon we will switch on more secured server.
				$.ajax({
			        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
			        type: 'POST',
			        data: {action:action, reviewer_id:reviewer_id, reviewer_status:c_reviewer_status},
			        dataType: 'json',
			        success: function(data){
			        	
			        	console.log('Check Peg Peg Post: ' + data.exec_message);

			        	if(data.exec_message == 'Success!'){
			        		localStorage.setItem('changePegStorage', 'Post Done Check Peg!');
			        	}

			        },
			        error: function(jxhr){
		               //console.log(jxhr.responseText);
		               console.log('Send Pending Failed');
		           }
			    });

			});

		}

	}, 8000);

	


	$(document).on('click', '._2ph_ ._42ft._4jy0._4jy3._517h._51sy', function(){

		reviewer_status = 'In production';
		localStorage.setItem('revStatusStorage', reviewer_status);
		localStorage.setItem('changePegStorage', 'Pending');
		localStorage.setItem('isUserClickedUnavailable', 'No');

		console.log(localStorage.getItem('revStatusStorage'));
		console.log(localStorage.getItem('changePegStorage'));
		
	});

	$(document).on('click', '.uiContextualLayer ._8l9y', function(){

		

		reviewer_status = $(this).text();

		localStorage.setItem('revStatusStorage', reviewer_status);
		localStorage.setItem('changePegStorage', 'Pending');

		console.log(localStorage.getItem('revStatusStorage'));
		console.log(localStorage.getItem('changePegStorage'));

		if($(this).text() == "Unavailable"){
			localStorage.setItem('isUserClickedUnavailable', 'Yes');
		}

		//alert('Your status is now: ' + $(this).text());

	});

	$(document).on('click', '.mrm ._4-u3._3a8w', function(){

		//alert($(this).text());

		if($(this).text() == 'Review'){

			reviewer_status = 'In production';
			localStorage.setItem('revStatusStorage', reviewer_status);
			localStorage.setItem('changePegStorage', 'Pending');
			localStorage.setItem('isUserClickedUnavailable', 'No');

			console.log(localStorage.getItem('revStatusStorage'));
			console.log(localStorage.getItem('changePegStorage'));

		}

	});

	// Check the difference between mouse moved and current timestamp

	setTimeout(function(){

		console.log('Check the difference between mouse moved and current timestamp');

		var mm = parseInt(localStorage.getItem('mouseMoved'));
		var cts = Date.now();
		var diff = cts - mm;
		var c_ts_s = diff / 1000;

		if(c_ts_s > 10){
			console.log('Seconds: ' + c_ts_s);
			console.log('Time: ' + msToTime(diff));
		}



		

	}, 3000);

	function msToTime(s) {
	  var ms = s % 1000;
	  s = (s - ms) / 1000;
	  var secs = s % 60;
	  s = (s - secs) / 60;
	  var mins = s % 60;
	  var hrs = (s - mins) / 60;

	  return hrs + ':' + mins + ':' + secs + '.' + ms;
	}


	//Initialize the mouse storage value
	chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
		//console.log('Mouse Moved: ' + MouseMoved);
	});


	$(document).on('mousemove', function(){
	
		clearTimeout(timeOut);

		if(MouseMoved == 0){

			MouseMoved = 1;

			localStorage.setItem('mouseMoved', Date.now());

			chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});	

		}

		timeOut = setTimeout(function(){

			MouseMoved = 0;
			chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});
			
		}, 1000);
        
  	});


	//Counter Auto Refresh
  	var refreshCounterTimer = null;
	refreshCounterTimer = setTimeout(function(){

		if(localStorage.getItem('revStatusStorage') == "Unavailable" || localStorage.getItem('revStatusStorage') == "In production"){
    	 	console.log('Auto refresh counter');
			jQuery('._7doi ._3-92 ._699i').click();
			IT();
    	}
		// Do something here when it happens ...
	},5000);

	chrome.storage.onChanged.addListener(function(changes, namespace) {

	    if(changes['mouseStorage']){
	    	 if(localStorage.getItem('revStatusStorage') == "Unavailable" || localStorage.getItem('revStatusStorage') == "In production"){
	    	 	console.log("Timer End");
	    	 	IT();
	    	 }
	    }
	    if(changes['refreshCounter']){
	    	 clearTimeout(refreshCounterTimer);
	    	 //console.log('clear time out');
	    }


	});

	function IT(){
		
		clearInterval(idle);
		timer = -1;

		audio.pause(); // Stop playing
        audio.currentTime = 0; // Reset time
        
        timerStartIn = 481;
        $('.timer').html('User is active');
        $('.timer-content i').removeClass('animated shake infinite');
        $('.it-status').html('<span> <strong>User Status: </strong> <span class="active m-r-10">Active</span></span>');
	      
        idle = setInterval(function(){

            timer++;
           	//console.log(timer);
           	//console.log("Timer Start");
           	chrome.storage.local.set({"refreshCounter": timer}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});

           	 timerStartIn--;
        	$('.timer').html('User is active. <br><br> Idle starts in ' + secondsToHms(timerStartIn));

        	if((timer > 3 && timer <= 449) && (localStorage.getItem('revStatusStorage') == "Unavailable") && (localStorage.getItem('isUserClickedUnavailable') == "Yes")){ 

        		//console.log('5 seconds and Unavailable!');
        		audio.play();

        	}


     		if(timer == 8){ 

    //  			if(localStorage.getItem('revStatusStorage') == "Unavailable" && localStorage.getItem('isUserClickedUnavailable') == false){

				// 	localStorage.setItem('revStatusStorage', $('._699p ._699o').text());

				//     chrome.storage.local.get("h_t_revid", function(res) {

				// 		action = 'Reviewer Change Status';
				// 		reviewer_status = 'In production';

				// 		//For development purpose only. Soon we will switch on more secured server.
				// 		$.ajax({
				// 	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
				// 	        type: 'POST',
				// 	        data: {action:action, reviewer_id:res.h_t_revid, reviewer_status:reviewer_status},
				// 	        dataType: 'json',
				// 	        success: function(data){

				// 	        	console.log('Reviewer Status Change to In production: ' + data.exec_message);

				// 	        	if(data.exec_message == 'Success!'){
				// 	        		localStorage.setItem('changePegStorage', 'Post Done!');
				// 	        	}

				// 	        },
				// 	        error: function(jxhr){
				//                console.log(jxhr.responseText);
				//                 //do some thing
				//            }
				// 	    });

				// 	});

				// }
     		}

        	if(timer == 450){

        		console.log('Idle for 5 minutes. Sending Unavailability on Database!');
        		localStorage.setItem('isUserClickedUnavailable', 'Yes');

        		chrome.storage.local.get("h_t_revid", function(res) {
		    	
					reviewer_id = res.h_t_revid;
					console.log('Reviewer ID: ' + reviewer_id);

					action = 'Reviewer Change Status';
					reviewer_status = 'Unavailable';
					localStorage.setItem('revStatusStorage', reviewer_status);

					//For development purpose only. Soon we will switch on more secured server.
	        		$.ajax({
				        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
				        type: 'POST',
				        data: {action:action, reviewer_id:reviewer_id, reviewer_status:reviewer_status},
				        dataType: 'json',
				        success: function(data){

				        	console.log('Reviewer Status Change to Unavailable : '+ data.exec_message);

				        	if(data.exec_message == 'Success!'){
				        		jQuery('._7doi ._3-92 ._699i').click();
				        		setTimeout(function(){
				        			jQuery('.uiContextualLayer ._8l9y').last().click();
				        		},1000);
				        	}

				        },
				        error: function(jxhr){
			               //console.log(jxhr.responseText);
			               console.log('8mins Timer send availability failed');

			               jQuery('._7doi ._3-92 ._699i').click();
			        		setTimeout(function(){
			        			jQuery('.uiContextualLayer ._8l9y').last().click();
			        		},1000);
			           }
				    });

				});

        	}

            if(timer >= 480){
             	//Idle

             	audio.play();

             	$('.timer').html('You are idle for about <br> ' + secondsToHms(timer - 481) +'.');
                //console.log(timer);
                $('.timer-content i').addClass('animated shake infinite');
                $('.it-status').html('<span> <strong>User Status: </strong> <span class="idle m-r-10">Idle</span></span>');
      
            }
            
        }, 100);
	}

	// $(document).on('click', '.uiContextualLayer ._8l9y', function(){

	// 	alert('Your status is now: ' + $(this).text());

	// });

	// $(document).on('keydown', function(e){
	//     //_5v-0 _53il
	// 	if(e.which == 107){
	// 		console.log($('.uiContextualLayer ._8l9y').length);
	// 	}

	// });

	

},
handleAjaxTest = function(){

	var test = "test";

	var lastname = 'Enojado';
	var firstname = 'Mark';
	var username = 'mark.enojado';
	var password = 'admin';
	var app_token = '1234567890';

	var reviewer_id = 1;
	var reviewer_status = '';
	var action = '';

	$(document).on('click', '.timer-content i', function(){

		action = 'Reviewer Change Status';
		reviewer_status = 'Unavailable';

		$.ajax({
	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
	        type: 'POST',
	        data: {action:action, reviewer_id:reviewer_id, reviewer_status:reviewer_status},
	        success: function(data){
	        	console.log('ok!' + data);
	        },
	        error: function(jxhr){
               console.log(jxhr.responseText);
                //do some thing
           }
	    });

		
	});

// $.ajax({
// 	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
// 	        type: 'POST',
// 	        data: {action:action, lastname:lastname, firstname:firstname, username:username, password:password, app_token:app_token},
// 	        success: function(data){
// 	        	console.log('ok!' + data);
// 	        },
// 	        error: function(jxhr){
//                console.log(jxhr.responseText);
//                 //do some thing
//            }
// 	    });
	


	


},
handleAppLogin = function(){

	$(document).on('click', '#h-t-lgn-sbmt', function(e){

		var action = "lgn_usr";
		var h_t_unme = $('#h-t-unme').val();
		var h_t_pswrd = $('#h-t-pswrd').val();
		
		//For development purpose only. Soon we will switch on more secured server.
		$.ajax({
	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/auth_user.php',
	        type: 'POST',
	        data: {action:action, h_t_unme:h_t_unme, h_t_pswrd:h_t_pswrd},
	        dataType: 'json',
	        success: function(data){
	        	console.log('Login: ' + data.loginMsg);

	        	if(data.loginMsg == 'Success!'){

	        		chrome.storage.local.set({"h_t_revid": data.h_t_revid}, function() {
						console.log('Reviewer ID: ' + data.h_t_revid);
					});

	        		chrome.storage.local.set({"h_t_unme": data.h_t_unme}, function() {
						console.log('Username: ' + data.h_t_unme);
					});

					chrome.storage.local.set({"h_t_pswrd": data.h_t_pswrd}, function() {
						console.log('Password: ' + data.h_t_pswrd);
					});

					chrome.storage.local.set({"lg_token": data.lg_token}, function() {
						console.log('Login Token: ' + data.lg_token);
					});

					localStorage.setItem('isLoginStorage', true);

					$('.app-login-block').remove();

					$.get(chrome.extension.getURL('app.html'), function(appblock) {
						$(appblock).appendTo('.horizone-tools');
					});
	        	}

	        },
	        error: function(jxhr){
               //console.log(jxhr.responseText);
               console.log('Login Auth Failed');
           }
	    });

	});

	setTimeout(function(){

		chrome.storage.local.get("lg_token", function(res) {
			//console.log('Login Token: ' + res.lg_token);

			if(res.lg_token == ''){
				console.log('Empty Token');
			}
			else {
				//console.log('Login Token: ' + res.lg_token);

				var action_c = "check_lg_token";

				//For development purpose only. Soon we will switch on more secured server.
				$.ajax({
			        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/auth_user.php',
			        type: 'POST',
			        data: {action_c:action_c, c_lg_token:res.lg_token},
			        dataType: 'json',
			        success: function(data){

			        	console.log('Check Login Token: ' + data.authMsg);

			        	if(data.authMsg == 'Success!'){

			        		localStorage.setItem('isLoginStorage', true);

			        		$('.app-login-block').remove();

							$.get(chrome.extension.getURL('app.html'), function(appblock) {
								$(appblock).appendTo('.horizone-tools');
							});
			        	}

			        },
			        error: function(jxhr){
		               //console.log(jxhr.responseText);
		               console.log('Login Token Check Auth Failed');
		           }
			    });

				
			}

		});

	},100);

},
handleDebugApp = function(){

	$(document).on('keydown', function(e){

		if(e.which == 107){
			
			//console.log($('.mrm ._4-u3._3a8w').text());
			//console.log($('._699p ._699o').text());
			//jQuery('.uiContextualLayer ._8l9y').last().click();
			//console.log($('.uiContextualLayer ._8l9y').length);
			//console.log($('._4bl9._5gqj ._3-8k ._271k._271m._1qjd._7tvm._7tv2._7tv4').length);
			//console.log($('._2ph_ ._42ft._4jy0._4jy3._517h._51sy').length);

			// chrome.storage.local.clear(function(){
			// 	console.log('Cleared');
			// });

			// localStorage.clear();
			// console.log('Cleared');

			if($('._699p ._699o').text()[0] == 'In production'){
				console.log('Exist!')
			}
			else {
				console.log('Not Exist!')
			}
		}

	});



},
Main = function() {
    'use strict';

    return {
        init: function() {

			handleSrtGUI(),
			handleInterface(),
			handleTextToSpeech(),
			handleChronopeg(),
			//handleIdleTimer(),
			handleFullScreenMode(),
			handleAppLogin(),
			handleDebugApp()


	
        }
    }
}();
Main.init();

function secondsToHms(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);

    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay + sDisplay; 
}
