/*------------------------------------

Project Name: Horizone Tool
Author: SME Innovation Team
Date: April 2020
Version: 1.1.3
Company: Majorel PH

---------------------------------------*/


var handleSrtGUI = function(){

$('body').prepend('<div class="horizone-element bootstrap" style="display: block"></div>');

$.get(chrome.extension.getURL('horizone.html'), function(data) {
	$(data).appendTo('.horizone-element');
});

},
handleInterface = function(){

var gui = false;

$(document).on('keydown', function(e){

	if(e.which == 45){
		
		if(!gui){
			$('.app-block').fadeIn();
			gui = true;
		}
		else {
			$('.app-block').fadeOut();
			gui = false;
		}

		//console.log(gui);
		
	}


});


$(document).on('click', '.menu-open-button', function(){
   	$('.app-block').fadeIn();
    gui = true;
});

/* Menu
--------------------------------------------*/

$(document).on('click', '.menu-item', function(){

	$('.highlighter-data').html('');

	$('.shortcut-menu a').removeClass('active');
	$(this).toggleClass('active');

	if ($(this).hasClass('m-idle-timer')){

		$('.idle-timer-content, .idle-note').fadeIn(1000);
		
	}



});

},
handleFullScreenMode = function(){

/* Get the element you want displayed in fullscreen mode (a video in this example): */
var elem = document.documentElement;
var fullScreenStatus = false;

$(document).on('click', '.m-fullscreen', function(){
	

	if(!fullScreenStatus){
		$('.m-fullscreen i').removeClass('ion-md-expand').addClass('ion-md-contract');
		openFullscreen(elem);
		fullScreenStatus = true;
	}
	else {
		$('.m-fullscreen i').removeClass('ion-md-contract').addClass('ion-md-expand');
		closeFullscreen();
		fullScreenStatus = false;
	}
});

	/* When the openFullscreen() function is executed, open the video in fullscreen.
	Note that we must include prefixes for different browsers, as they don't support the requestFullscreen method yet */
	function openFullscreen() {
	  if (elem.requestFullscreen) {
	    elem.requestFullscreen();
	  } else if (elem.mozRequestFullScreen) { /* Firefox */
	    elem.mozRequestFullScreen();
	  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
	    elem.webkitRequestFullscreen();
	  } else if (elem.msRequestFullscreen) { /* IE/Edge */
	    elem.msRequestFullscreen();
	  }
	}

	function closeFullscreen() {
	  if (document.exitFullscreen) {
	    document.exitFullscreen();
	  } else if (document.mozCancelFullScreen) { /* Firefox */
	    document.mozCancelFullScreen();
	  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
	    document.webkitExitFullscreen();
	  } else if (document.msExitFullscreen) { /* IE/Edge */
	    document.msExitFullscreen();
	  }
	}

},
handleIdleTimer = function(){

	var audio_url = chrome.runtime.getURL('audio/bells.mp3');
  	var audio = new Audio(audio_url);

  	var timerStartIn;
	var timer;
	var idle = null;
	var timeOut = null;
	var MouseMoved = 0;

	var reviewer_id = 1;
	var reviewer_status = '';
	var action = '';

	//Initialize the mouse storage value
	chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
		//console.log('Mouse Moved: ' + MouseMoved);
	});


	$(document).on('mousemove', function(){

	
		clearTimeout(timeOut);

		if(MouseMoved == 0){
			MouseMoved = 1;

			reviewer_status = "In production";

			chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});
		}



		timeOut = setTimeout(function(){

			MouseMoved = 0;
			chrome.storage.local.set({"mouseStorage": MouseMoved}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});
			
		}, 1000);
        
  	});


	//Counter Auto Refresh
  	var refreshCounterTimer = null;
	refreshCounterTimer = setTimeout(function(){
		console.log('Auto refresh counter');
		jQuery('._7doi ._3-92 ._699i').click();
		 IT();
		// Do something here when it happens ...
	},5000);

	chrome.storage.onChanged.addListener(function(changes, namespace) {

	    if(changes['mouseStorage']){
	    	 IT();
	    }
	    if(changes['refreshCounter']){
	    	 clearTimeout(refreshCounterTimer);
	    	 //console.log('clear time out');
	    }


	});

	function IT(){
		
		clearInterval(idle);
		timer = -1;

		audio.pause(); // Stop playing
        audio.currentTime = 0; // Reset time
        
        timerStartIn = 301;
        $('.timer').html('User is active');
        $('.timer-content i').removeClass('animated shake infinite');
        $('.it-status').html('<span> <strong>User Status: </strong> <span class="active m-r-10">Active</span></span>');
	      
        idle = setInterval(function(){

            timer++;
           	//console.log(timer);
           	chrome.storage.local.set({"refreshCounter": timer}, function() {
				//console.log('Mouse Moved: ' + MouseMoved);
			});

           	 timerStartIn--;
        	$('.timer').html('User is active. <br><br> Idle starts in ' + secondsToHms(timerStartIn));

        	if(timer == 300){

        		console.log('Idle for 5 minutes. Sending Unavailability on Database!');

        		action = 'Reviewer Unavailable';
				reviewer_status = 'Unavailable';

        		$.ajax({
			        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
			        type: 'POST',
			        data: {action:action, reviewer_id:reviewer_id, reviewer_status:reviewer_status},
			        success: function(data){
			        	console.log('ok!' + data);
			        },
			        error: function(jxhr){
		               console.log(jxhr.responseText);
		                //do some thing
		           }
			    });
        	}

            if(timer >= 300){
             	//Idle

             	$('.timer').html('You are idle for about <br> ' + secondsToHms(timer - 301) +'.');
                //console.log(timer);
                audio.play();
                $('.timer-content i').addClass('animated shake infinite');
                $('.it-status').html('<span> <strong>User Status: </strong> <span class="idle m-r-10">Idle</span></span>');
      
            }
            
        }, 100);
	}

},
handleAjaxTest = function(){

	var test = "test";

	var lastname = 'Enojado';
	var firstname = 'Mark';
	var username = 'mark.enojado';
	var password = 'admin';
	var app_token = '1234567890';

	var reviewer_id = 1;
	var reviewer_status = '';
	var action = '';

	$(document).on('click', '.timer-content i', function(){

		action = 'Reviewer Unavailable';
		reviewer_status = 'Unavailable';

		$.ajax({
	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
	        type: 'POST',
	        data: {action:action, reviewer_id:reviewer_id, reviewer_status:reviewer_status},
	        success: function(data){
	        	console.log('ok!' + data);
	        },
	        error: function(jxhr){
               console.log(jxhr.responseText);
                //do some thing
           }
	    });

		
	});

// $.ajax({
// 	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/chrome_exec.php',
// 	        type: 'POST',
// 	        data: {action:action, lastname:lastname, firstname:firstname, username:username, password:password, app_token:app_token},
// 	        success: function(data){
// 	        	console.log('ok!' + data);
// 	        },
// 	        error: function(jxhr){
//                console.log(jxhr.responseText);
//                 //do some thing
//            }
// 	    });
	


	


},
handleAppLogin = function(){

	var action = "Login User";

	$(document).on('click', '#h-t-lgn-sbmt', function(e){

		var h_t_unme = $('#h-t-unme').val();
		var h_t_pswrd = $('#h-t-pswrd').val();
		
		$.ajax({
	        url: 'https://technobeastv2.000webhostapp.com/system/chromeextension/auth_user.php',
	        type: 'POST',
	        data: {action:action, h_t_unme:h_t_unme, h_t_pswrd:h_t_pswrd},
	        success: function(data){
	        	console.log('Ok! \n' + data);
	        },
	        error: function(jxhr){
               console.log(jxhr.responseText);
                //do some thing
           }
	    });

	});

},
Main = function() {
    'use strict';

    return {
        init: function() {

			handleSrtGUI(),
			handleInterface(),
			handleFullScreenMode(),
			handleAppLogin()
	
        }
    }
}();
Main.init();

function secondsToHms(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);

    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay + sDisplay; 
}
